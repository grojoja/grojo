package hw2;

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private WeightedQuickUnionUF sharma;
    private WeightedQuickUnionUF jarma;
    private boolean[][] grid;
    private int size;
    private int top = 0;
    private int bottom;
    private int openspaces;

    public Percolation(int N) {
        if (N <= 0) {
            throw new IllegalArgumentException();
        }
        this.size = N;
        int gridspaces = N * N;
        sharma = new WeightedQuickUnionUF(gridspaces + 2);
        jarma = new WeightedQuickUnionUF(gridspaces + 1);
        grid = new boolean[N][N];
        bottom = N * N + 1;
        openspaces = 0;
    }

    public void open(int row, int col) {
        checker(row, col);
        if (!(isOpen(row, col))) {
            grid[row][col] = true;
            if (row == 0) {
                sharma.union(location(row, col), top);
                jarma.union(location(row, col), top);
            }
            if (row == size - 1) {
                sharma.union(location(row, col), bottom);
            }
            openspaces++;
            if (col > 0 && isOpen(row, col - 1)) {
                sharma.union(location(row, col - 1), location(row, col));
                jarma.union(location(row, col - 1), location(row, col));
            }
            if (row > 0 && isOpen(row - 1, col)) {
                sharma.union(location(row - 1, col), location(row, col));
                jarma.union(location(row - 1, col), location(row, col));
            }
            if (row < size - 1 && isOpen(row + 1, col)) {
                sharma.union(location(row + 1, col), location(row, col));
                jarma.union(location(row + 1, col), location(row, col));
            }
            if (col < size - 1 && isOpen(row, col + 1)) {
                sharma.union(location(row, col + 1), location(row, col));
                jarma.union(location(row, col + 1), location(row, col));
            }
        }
    }

    public boolean isOpen(int row, int col) {
        checker(row, col);
        return grid[row][col];
    }

    private boolean checker(int row, int col) {
        if (row >= 0 || col >= 0 || row < size || col < size) {
            return true;
        } else {
            throw new java.lang.IndexOutOfBoundsException("sharma jarma sing jarm");
        }
    }

    public boolean isFull(int row, int col) {
        checker(row, col);
        if (!isOpen(row, col)) {
            return false;
        }
        return jarma.connected(location(row, col), top);
    }

    public int numberOfOpenSites() {
        return openspaces;
    }

    public boolean percolates() {
        return sharma.connected(top, bottom);
    }

    private int location(int row, int col) {
        return (size * (row) + col);
    }
}
