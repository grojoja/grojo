package hw2;

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

import static java.lang.Math.sqrt;

public class PercolationStats {
    private double thesims[];
    private int opensss;

    public PercolationStats(int N, int T, PercolationFactory pf) {
        if (N <= 0 || T <= 0) {
            throw new java.lang.IllegalArgumentException();
        }
        this.thesims = new double[T];
        for (int i = 0; i < T; i++) {
            Percolation shimma = pf.make(N);
            while (!shimma.percolates()) {
                int row = StdRandom.uniform(0, N);
                int col = StdRandom.uniform(0, N);
                if (!shimma.isOpen(row, col)) {
                    shimma.open(row, col);
                }
            }
            double num = (double) shimma.numberOfOpenSites()/ (N*N);
            thesims[i] = num;
        }

    }

    public double mean() {
        return StdStats.mean(this.thesims);
    }

    public double stddev() {
        return StdStats.stddev(this.thesims);
    }

    public double confidenceLow() {
        double size = (double) this.thesims.length;
        double limit = this.mean() - (1.96 * this.stddev() / Math.sqrt(size));
        return limit;
    }

    public double confidenceHigh() {
        double size = (double) this.thesims.length;
        double limit = this.mean() + (1.96 * this.stddev() / Math.sqrt(size));
        return limit;
    }
}
