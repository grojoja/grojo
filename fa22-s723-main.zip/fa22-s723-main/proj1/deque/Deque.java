package deque;

public interface Deque<T> {
    void addFirst(T x);

    void addLast(T x);

    default boolean isEmpty() {
        return size() == 0;
    }

    int size();

    void printDeque();

    T removeFirst();

    T removeLast();

    T get(int i);

    boolean equals(Object o);
}
