package ngordnet.main;

public class DDFS {
    /* This was also borrowed from Princeton Algorithms */
    private boolean marked[];
    private int count;

    public DDFS(DirectedGraph graph, Iterable<Integer> files) {
        marked = new boolean[graph.V()];
        validationv(files);
        for (int i : files) {
            if (!marked[i]) {
                dfs(graph, i);
            }
        }
    }

    public boolean validation(int v) {
        int l = marked.length;
        if (v < 0 || v >= l) {
            throw new IllegalArgumentException();
        }
        return true;
    }

    private void dfs(DirectedGraph graph, int v) {
        count++;
        marked[v] = true;
        for (int i : graph.adjacency(v)) {
            if (!marked[i]) {
                dfs(graph, i);
            }
        }
    }

    public boolean marked(int i) {
        validation(i);
        return marked[i];
    }

    private void validationv(Iterable<Integer> vertices) {
        if (vertices == null) {
            throw new IllegalArgumentException();
        }
        int count = 0;
        for (Integer v : vertices) {
            count++;
            if (v == null) {
                throw new IllegalArgumentException();
            }
            validation(v);
        }
        if (count == 0) {
            throw new IllegalArgumentException();
        }
    }

}
