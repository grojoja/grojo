package ngordnet.main;

import edu.princeton.cs.algs4.Bag;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Stack;


/* Todd Yu said that all we need is the addEdge and adjacency list, everything else not needed
Samuel Berkun on Ed said that we can copy the Princeton one but not preferred because of
useless methods

Todd Yu said that Josh Hug wants us to create the graph class but is not too pressed if we
just base it off the Princeton one and source it
 */

public class DirectedGraph {
    private final int vertex;
    private int edge;
    private int[] degree;
    private Bag<Integer>[] adjacency;

    public DirectedGraph(int vertex) {
        if (vertex < 0) {
            throw new IllegalArgumentException();
        }
        this.vertex = vertex;
        this.edge = 0;
        degree = new int[vertex];
        adjacency = (Bag<Integer>[]) new Bag[vertex];
        for (int i = 0; i < vertex; i++) {
            adjacency[i] = new Bag<>();
        }
    }

    public int V() {
        return vertex;
    }

    public void addEdge(int v, int z) {
        checkVertex(v);
        checkVertex(z);
        adjacency[v].add(z);
        degree[z]++;
        edge++;
    }

    public Iterable<Integer> adjacency(int v) {
        return adjacency[v];
    }


    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(vertex + " vertices, " + edge + " edges " + "\n");
        for (int i = 0; i < vertex; i++) {
            s.append(String.format("%d ", i));
            for (int j : adjacency[i]) {
                s.append(String.format("%d", j));
            }
            s.append("\n");
        }
        return s.toString();
    }

    public boolean checkVertex(int v) {
        if (v < 0 || v >= this.V()) {
            throw new IllegalArgumentException();
        }
        return true;
    }
}
