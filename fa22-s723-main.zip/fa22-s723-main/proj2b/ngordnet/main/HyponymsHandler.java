package ngordnet.main;

import ngordnet.hugbrowsermagic.NgordnetQuery;
import ngordnet.hugbrowsermagic.NgordnetQueryHandler;
import ngordnet.ngrams.NGramMap;

import java.util.*;

public class HyponymsHandler extends NgordnetQueryHandler {
    private WordNet sharma;
    private NGramMap map;

    public HyponymsHandler(WordNet sharma) {
        this.sharma = sharma;
    }

    public HyponymsHandler(WordNet sharma, NGramMap map) {
        this.sharma = sharma;
        this.map = map;
    }

    private Set<String> creation(NgordnetQuery q) {
        Set<String> jinop = new HashSet<>();
        Set<String> jumpop = new HashSet<>();
        for (String word : q.words()) {
            jinop.addAll(sharma.hyponymCreator(word));
            if (word == q.words().get(0) && jumpop.isEmpty()) {
                jumpop.addAll(jinop);
            }
            jumpop.retainAll(jinop);
            jinop = new HashSet<>();
            if (jumpop.isEmpty()) {
                return jumpop;
            }
        }
        return jumpop;
    }

    public String handle(NgordnetQuery q) {
        String w = "";
        if (q.k() > 0) {
            w = helper(q).toString();
        } else {
            Set<String> jarmp = new HashSet<>();
            if (creation(q) != null) {
                jarmp = creation(q);
            }
            ArrayList<String> meep = new ArrayList<>();
            if (jarmp != null) {
                meep.addAll(jarmp);
            }
            Collections.sort(meep);
            w = meep.toString();
        }
        return w;
    }

    //Idea to use 3 HashMaps came from math man on Discord
    private ArrayList<String> helper(NgordnetQuery q) {
        /* https://edstem.org/us/courses/25377/discussion/1970186?comment=4668822 */
        HashMap<Double, String> count = new HashMap<>();
        HashSet<String> words = new HashSet<>();
        ArrayList<Double> pq = new ArrayList<>();
        Set<String> jongom = new HashSet<>();
        words.addAll(creation(q));
        for (String word : words) {
            Double number = 0.0;
            sharma.checker(word);
            for (int i = q.startYear(); i <= q.endYear(); i++) {
                if (map != null) {
                    if (map.countHistory(word, q.startYear(), q.endYear()).get(i) != null) {
                        if (map.countHistory(word, q.startYear(), q.endYear()).get(i) > 0.0) {
                            number += map.countHistory(word, q.startYear(), q.endYear()).get(i);
                        }
                    }
                }
            }
            if (number != 0.0) {
                count.put(number, word);
                pq.add(number);
            }
        }
        if (count.size() == 0) {
            return new ArrayList<>();
        }
        Collections.sort(pq);
        Collections.reverse(pq);
        int i = 0;
        if (count.size() >= q.k()) {
            while (jongom.size() < q.k()) {
                jongom.add(count.get(pq.get(i)));
                i++;
            }
        } else {
            while (jongom.size() < count.size()) {
                jongom.add(count.get(pq.get(i)));
                i++;
            }
        }
        ArrayList<String> another = new ArrayList<>();
        another.addAll(jongom);
        Collections.sort(another);
        return another;
    }
}
