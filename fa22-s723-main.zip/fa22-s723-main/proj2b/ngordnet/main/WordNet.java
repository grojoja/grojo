package ngordnet.main;

import edu.princeton.cs.algs4.In;

import java.util.*;

/*
Two files, one file of definitions. One for ID then comma then word then definition
Hyponym file, ID then hyponym number

Word ID --> word 11, action
WordID --> hyponym, 11,12
combine the two maps to create the graph

Idea of using one HashMap and a Graph came from Ed -- Christine Yang
The Graph would be used to keep track of the hyponym relations, basically
just to check if the items were related at all.

Then use my HashMap to map the IDs to words.
Ed Post linked here:
https://edstem.org/us/courses/25377/discussion/2011598

https://edstem.org/us/courses/25377/discussion/2041494?comment=4669036
Idea to use sets here. Thank you, Samuel Berkun.
 */
public class WordNet {
    private HashMap<Integer, Set<String>> map = new HashMap<>();
    private String file1;
    private String file2;
    private int count;
    private DirectedGraph graph;

    private void lines() {
        In sys = new In(file1);
        while (!sys.isEmpty()) {
            sys.readLine();
            count++;
        }
    }

    /* Todd Yu told me that I do not need to read my first file in because
    it would be unnecessary, and I have already created a method to read the synsets in.
    Confirmed that logically, this would work.
     */
    public WordNet(String file1, String file2) {
        this.file2 = file2;
        this.file1 = file1;
        In sharmajarmasingerbomberjarma = new In(file2);
        lines();
        conversion();
        graph = new DirectedGraph(count);
        while (!sharmajarmasingerbomberjarma.isEmpty()) {
            String jem = sharmajarmasingerbomberjarma.readLine();
            String[] jarma = jem.split(",");
            /* I originally only added indices 0 and 1
            but Todd Yu told me that all of the numbers in the list were children
            of the first number, so that meant that I would need to addEdge
            to the first number for all of the elements i
             */
            for (int i = 1; i < jarma.length; i++) {
                int key = Integer.parseInt(jarma[0]);
                int secondKey = Integer.parseInt(jarma[i]);
                graph.addEdge(key, secondKey);
            }
            // 0,1,2 graph.addEdge(0,1) 0 --> 1 graph.addEdge(0,2) 2 <-- 0 --> 1
        }
    }

    public ArrayList<String> hyponymCreator(String word) {
        HashSet<String> jarmjarm = new HashSet<>();
        HashSet<Integer> key = new HashSet<>();
        /* Original line of code has a helper function to check
        if the set had the word, but it would return the entire set.
        Meshan told me that the problem was that the set would have the word,
        so that meant that I would always get the whole set. Instead,
        what I should do is check to see if the get at each index
        equals the word, then that would actually check which indices to put in
         */
        if (checker(word) == false) {
            return new ArrayList<>();
        }
        for (Integer keyy : map.keySet()) {
            if (map.get(keyy).contains(word)) {
                key.add(keyy);
            }
        }
        Set<Integer> set = children(graph, key);
        for (int i : set) {
            if (map != null) {
                jarmjarm.addAll(map.get(i));
            }
        }
        ArrayList<String> shingjom = new ArrayList<>();
        shingjom.addAll(jarmjarm);
        /* idea to use Collections.sort from here
        https://edstem.org/us/courses/25377/discussion/1970175?comment=4587900
        Thank you, Alex for answering my question so promptly.
         */
        Collections.sort(shingjom);
        return shingjom;
    }
    /* Idea to use Sets came from this Ed Post
    https://edstem.org/us/courses/25377/discussion/2041494

    edit: found out we actually do need to split the multi-words by the
        whitespace. rip runtime
        https://edstem.org/us/courses/25377/discussion/2021471
        Source above

        Switched to Sets of Strings for my hashmap instead
        now the map is Set<Integer, String>, solves the issue of HashMap
        overwriting the data
     */

    private void conversion() {
        In file = new In(file1);
        while (!file.isEmpty()) {
            HashSet<String> scaryoctopus = new HashSet<>();
            String jem = file.readLine();
            String[] jarm = jem.split(",");
            int key = Integer.parseInt(jarm[0]);
            String string = (jarm[1]);
            if (string.contains(" ")) {
                String[] array = string.split(" ");
                for (int i = 0; i < array.length; i++) {
                    scaryoctopus.add(array[i]);
                }
            } else {
                scaryoctopus.add(string);
            }
            map.put(key, scaryoctopus);
        }
    }

    public Set<Integer> children(DirectedGraph graph, Set<Integer> sysID) {
        DDFS dfs;
        if (graph != null && sysID != null) {
            dfs = new DDFS(graph, sysID);
        } else {
            return new HashSet<>();
        }
        HashSet<Integer> number = new HashSet<>();
        for (int i = 0; i < graph.V(); i++) {
            if (dfs.marked(i)) {
                number.add(i);
            }
        }
        return number;
    }

    public boolean checker(String word) {
        int ham = 0;
        for (Integer i : map.keySet()) {
            if (map.get(i).contains(word)) {
                ham++;
            }
        }
        return ham > 0;
    }
}

